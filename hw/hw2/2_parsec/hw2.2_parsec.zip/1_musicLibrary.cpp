#include <stdio.h>
int main(int argc, char *argv[])   /* here is a comment 
comment test*/
{
        char my_char = ‘A’;
        for (int i=0; i<1024; ++i)
	printf("\"Hello\" she said.\n");
}
